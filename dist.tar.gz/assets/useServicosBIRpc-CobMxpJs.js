import{aC as c,bd as t,aU as u}from"./index-xOhzn_5R.js";import{i}from"./biRpcService-SNu6k3r2.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=c("Wrench",[["path",{d:"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z",key:"cbrjhi"}]]),l=5*6e4;function h({from:e,to:a,cidade:r,enabled:s=!0}){return t({queryKey:["rpc","servicos-bi",e,a,r??null],queryFn:()=>i(e,a,r),staleTime:l,placeholderData:u,enabled:s&&!!e&&!!a})}export{p as W,h as u};
